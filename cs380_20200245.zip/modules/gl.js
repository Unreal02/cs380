let gl;

function setGLContext(val) {
    gl = val;
}

export { gl as default, setGLContext };
